 "use client";
import { useEffect, useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { ArrowDownRight, ArrowUpRight, ArrowRight, Play, Sparkles, Menu, X, LockKeyhole, Plus, ExternalLink } from "lucide-react";
import { fallbackProfile, fallbackSkills, fallbackWork, type WorkItem } from "@/lib/content";
import { supabaseBrowser } from "@/lib/supabase";

type Profile = typeof fallbackProfile;
type SkillGroup = { group: string; skills: string[] };
const fade = { hidden: { opacity: 0, y: 24 }, show: { opacity: 1, y: 0, transition: { duration: .65, ease: [0.22,1,0.36,1] } } };

export default function Site() {
  const [profile, setProfile] = useState<Profile>(fallbackProfile);
  const [skills, setSkills] = useState<SkillGroup[]>(fallbackSkills);
  const [work, setWork] = useState<WorkItem[]>(fallbackWork);
  const [activeFilter, setActiveFilter] = useState("All");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const reduce = useReducedMotion();

  useEffect(() => {
    let live = true;
    async function load() {
      try {
        const db = supabaseBrowser();
        const [p, s, w] = await Promise.all([
          db.from("portfolio_profile").select("content").eq("id", 1).maybeSingle(),
          db.from("portfolio_skills").select("content").eq("id", 1).maybeSingle(),
          db.from("portfolio_work").select("*").order("sort_order", { ascending: true })
        ]);
        if (!live) return;
        if (p.data?.content) setProfile({ ...fallbackProfile, ...p.data.content });
        if (s.data?.content) setSkills(s.data.content);
        if (w.data?.length) setWork(w.data as WorkItem[]);
      } catch { /* The polished fallback portfolio works before setup. */ }
      if (live) setLoaded(true);
    }
    load(); return () => { live = false; };
  }, []);

  const categories = ["All", ...Array.from(new Set(work.map(x => x.category).filter(Boolean)))];
  const visibleWork = work.filter(x => activeFilter === "All" || x.category === activeFilter);
  const nav = [{ label: "About", href: "#about" }, { label: "Capabilities", href: "#capabilities" }, { label: "Work", href: "#work" }, { label: "Contact", href: "#contact" }];
  return <main>
    <div className="grain" aria-hidden="true" />
    <header className="topbar">
      <a className="wordmark" href="#" aria-label="Saud home">S<span>.</span></a>
      <nav className="desktop-nav">{nav.map(n => <a key={n.label} href={n.href}>{n.label}</a>)}</nav>
      <a className="nav-cta" href="#contact">Let&apos;s talk <ArrowUpRight size={15}/></a>
      <button className="mobile-menu" aria-label="Toggle menu" onClick={() => setMobileOpen(!mobileOpen)}>{mobileOpen ? <X/> : <Menu/>}</button>
    </header>
    {mobileOpen && <nav className="mobile-nav">{nav.map(n => <a key={n.label} href={n.href} onClick={() => setMobileOpen(false)}>{n.label}</a>)}</nav>}

    <section className="hero">
      <div className="hero-kicker"><span className="status-dot"/> BRAND MARKETING · CREATIVE · DIGITAL</div>
      <div className="hero-layout">
        <div className="hero-copy">
          <motion.p initial={reduce ? false : { opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .6 }} className="eyebrow">PORTFOLIO / 2026</motion.p>
          <motion.h1 initial={reduce ? false : { opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .8, delay: .08 }}>Make it<br/><span className="outline-word">matter.</span></motion.h1>
          <motion.p className="hero-sub" initial={reduce ? false : { opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: .35, duration: .8 }}>{profile.line}</motion.p>
          <motion.div className="hero-actions" initial={reduce ? false : { opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .45 }}>
            <a href="#work" className="button button-dark">Explore my work <ArrowDownRight size={17}/></a>
            <a href="#about" className="text-link">Get to know me <ArrowRight size={16}/></a>
          </motion.div>
        </div>
        <motion.div className="hero-art" initial={reduce ? false : { opacity: 0, scale: .92, rotate: 3 }} animate={{ opacity: 1, scale: 1, rotate: 0 }} transition={{ duration: .9, delay: .2 }}>
          <div className="art-orbit orbit-one"/><div className="art-orbit orbit-two"/>
          <div className="art-card">
            <div className="art-card-top"><span>INDEPENDENT THINKING</span><span>001 / 026</span></div>
            <div className="art-sculpture"><div className="sculpture-ring ring-a"/><div className="sculpture-ring ring-b"/><div className="sculpture-core"/></div>
            <div className="art-card-bottom"><span>STRATEGY<br/>MEETS INSTINCT</span><span className="asterisk">✳</span></div>
          </div>
          <div className="floating-label label-top">Ideas → Impact</div><div className="floating-label label-bottom"><Sparkles size={13}/> Built with curiosity</div>
        </motion.div>
      </div>
      <div className="hero-footer"><span>BASED IN {profile.location.toUpperCase()}</span><span>SCROLL TO EXPLORE <ArrowDownRight size={14}/></span><span>STRATEGY / STORY / EXECUTION</span></div>
    </section>

    <section id="about" className="section about-section">
      <motion.div className="section-heading" variants={fade} initial="hidden" whileInView="show" viewport={{ once: true, amount: .3 }}>
        <span className="section-index">01 / ABOUT</span><span className="section-note">A little context, a lot of curiosity.</span>
      </motion.div>
      <div className="about-grid">
        <motion.h2 variants={fade} initial="hidden" whileInView="show" viewport={{ once: true }}>Strategy-minded.<br/><em>Creatively wired.</em></motion.h2>
        <motion.div className="about-copy" variants={fade} initial="hidden" whileInView="show" viewport={{ once: true }}>
          <p>{profile.about}</p><p className="now-line"><span className="status-dot"/> RIGHT NOW: {profile.now}</p>
          <a href="#contact" className="under-link">More about the work <ArrowUpRight size={15}/></a>
        </motion.div>
      </div>
      <div className="principles">
        {[["01","Strategy first","Start with the objective. Make every decision earn its place."],["02","Creativity matters","Make the message distinctive, relevant, and memorable."],["03","Execution wins","Turn good ideas into clear, coordinated action."]].map(p => <motion.div className="principle" key={p[0]} variants={fade} initial="hidden" whileInView="show" viewport={{ once: true }}><span>{p[0]}</span><h3>{p[1]}</h3><p>{p[2]}</p></motion.div>)}
      </div>
    </section>

    <section id="capabilities" className="section skills-section">
      <div className="section-heading"><span className="section-index">02 / CAPABILITIES</span><span className="section-note">A practical toolkit, always evolving.</span></div>
      <div className="skills-intro"><h2>What I bring<br/><em>to the table.</em></h2><p>From the first strategic question to the final asset, I connect the moving parts that make a brand feel consistent and alive.</p></div>
      <div className="skill-list">{skills.map((g, i) => <motion.div className="skill-row" key={g.group} initial={reduce ? false : { opacity: 0, x: -18 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * .06 }}><div className="skill-num">0{i + 1}</div><h3>{g.group}</h3><div className="skill-tags">{g.skills.map(s => <span key={s}>{s}</span>)}</div><ArrowUpRight className="skill-arrow" size={18}/></motion.div>)}</div>
    </section>

    <section id="work" className="section work-section">
      <div className="section-heading"><span className="section-index">03 / SELECTED WORK</span><span className="section-note">Projects, campaigns, and experiments.</span></div>
      <div className="work-intro"><h2>Proof over<br/><em>promises.</em></h2><p>A selection of brand campaigns, creative coordination, and personal experiments. Media can be added through the private dashboard after setup.</p></div>
      <div className="filter-bar">{categories.map(c => <button key={c} className={activeFilter === c ? "filter active" : "filter"} onClick={() => setActiveFilter(c)}>{c}</button>)}</div>
      <div className="work-grid">{visibleWork.map((item, i) => <motion.article className="work-card" key={item.id} layout initial={reduce ? false : { opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * .07 }}>
        <div className={"work-media media-" + (i % 4)}>
          {item.media_url ? (item.media_type?.startsWith("video") ? <video src={item.media_url} controls playsInline /> : <img src={item.media_url} alt={item.title}/>) : <div className="media-placeholder"><span className="media-index">0{i + 1} / SELECTED WORK</span><div className="placeholder-symbol">{i === 0 ? "60" : i === 1 ? "↗" : i === 2 ? "◉" : "✳"}</div><span className="placeholder-caption">{item.category}</span></div>}
          <span className="media-arrow"><ArrowUpRight size={19}/></span>
        </div>
        <div className="work-meta"><span>{item.category}</span><span>{item.year}</span></div><h3>{item.title}</h3><p>{item.description}</p>
      </motion.article>)}</div>
      <div className="upload-hint"><LockKeyhole size={16}/><span>Have new work to show? Upload photos and videos from the private dashboard.</span></div>
    </section>

    <section className="manifesto"><div className="manifesto-mark">“</div><p>Good marketing makes a brand visible.<br/><em>Great marketing makes it mean something.</em></p><span>STRATEGY / CRAFT / CONSISTENCY</span></section>

    <section id="contact" className="section contact-section">
      <div className="section-heading"><span className="section-index">04 / CONTACT</span><span className="section-note">Good work starts with a clear conversation.</span></div>
      <div className="contact-grid"><div><h2>Have a good<br/><em>one in mind?</em></h2><p>For brand marketing, creative projects, and collaborations.</p></div>
        <div className="contact-links">
          {profile.email && <a href={`mailto:${profile.email}`}><span>Email</span><strong>{profile.email}</strong><ArrowUpRight size={18}/></a>}
          {profile.linkedin && <a href={profile.linkedin} target="_blank" rel="noreferrer"><span>LinkedIn</span><strong>Professional profile</strong><ExternalLink size={18}/></a>}
          {profile.instagram && <a href={profile.instagram} target="_blank" rel="noreferrer"><span>Instagram</span><strong>Creative work & updates</strong><ExternalLink size={18}/></a>}
          {!profile.email && !profile.linkedin && !profile.instagram && <div className="contact-placeholder"><p>Contact links will appear here once added in the dashboard.</p><a href="mailto:hello@example.com">Dashboard setup required <ArrowUpRight size={16}/></a></div>}
        </div>
      </div>
    </section>
    <footer><a className="wordmark" href="#">S<span>.</span></a><span>BUILT WITH INTENT. UPDATED AS I GROW.</span><a href="/admin" className="admin-link">ADMIN <LockKeyhole size={12}/></a><span>© {new Date().getFullYear()} SAUD</span></footer>
  </main>;
}