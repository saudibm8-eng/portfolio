-- Run this in Supabase SQL Editor.
-- 1) Create the first admin user in Supabase Dashboard > Authentication > Users > Add user.
-- 2) Keep signups disabled in Authentication settings.
-- 3) This schema permits public reads, but authenticated writes only. In a single-owner portfolio,
--    only create trusted administrator accounts in the Supabase dashboard.

create table if not exists public.portfolio_profile (
  id integer primary key check (id = 1),
  content jsonb not null default '{}'::jsonb
);
create table if not exists public.portfolio_skills (
  id integer primary key check (id = 1),
  content jsonb not null default '[]'::jsonb
);
create table if not exists public.portfolio_work (
  id text primary key,
  title text not null,
  category text not null default 'Project',
  year text not null default '',
  description text not null default '',
  media_url text,
  media_type text,
  featured boolean default false,
  sort_order integer not null default 0
);
alter table public.portfolio_profile enable row level security;
alter table public.portfolio_skills enable row level security;
alter table public.portfolio_work enable row level security;
drop policy if exists "Public can read profile" on public.portfolio_profile;
create policy "Public can read profile" on public.portfolio_profile for select using (true);
drop policy if exists "Authenticated can edit profile" on public.portfolio_profile;
create policy "Authenticated can edit profile" on public.portfolio_profile for all to authenticated using (true) with check (true);
drop policy if exists "Public can read skills" on public.portfolio_skills;
create policy "Public can read skills" on public.portfolio_skills for select using (true);
drop policy if exists "Authenticated can edit skills" on public.portfolio_skills;
create policy "Authenticated can edit skills" on public.portfolio_skills for all to authenticated using (true) with check (true);
drop policy if exists "Public can read work" on public.portfolio_work;
create policy "Public can read work" on public.portfolio_work for select using (true);
drop policy if exists "Authenticated can edit work" on public.portfolio_work;
create policy "Authenticated can edit work" on public.portfolio_work for all to authenticated using (true) with check (true);

insert into public.portfolio_profile(id,content) values
(1, '{"name":"Saud","role":"Brand Marketing · Digital Growth · Creative Production","line":"I turn brand objectives into campaigns people remember.","about":"I work at the intersection of brand strategy, digital marketing, creative production, and execution. My work spans restaurant marketing, influencer coordination, campaign planning, brand communication, and cinematic content. I enjoy building ideas from scratch, structuring campaigns, and using emerging tools to create better work and more efficient systems.","now":"Building sharper brand stories, better digital campaigns, and repeatable creative workflows.","email":"","instagram":"","linkedin":"","location":"Bengaluru, India"}'::jsonb)
on conflict(id) do nothing;
insert into public.portfolio_skills(id,content) values
(1, '[{"group":"Brand Marketing","skills":["Brand Strategy","Campaign Planning","Brand Positioning","Brand Communication","Integrated Marketing"]},{"group":"Social Media Management","skills":["Content Calendar Planning","Reels Strategy","Instagram Management","Community Management","Social Analytics","Audience Growth"]},{"group":"Digital Marketing","skills":["Meta Ads","Audience Targeting","Lead Generation","Campaign Optimization","Customer Acquisition"]},{"group":"Influencer & Production","skills":["Influencer Coordination","Creative Planning","Cinematic Brand Film Coordination","Content Production","Storytelling"]},{"group":"AI, Tools & Systems","skills":["AI Video Creation","Prompt Engineering","PDF Creation","Advanced Excel Workbooks","Spreadsheet Design","Workflow Automation"]}]'::jsonb)
on conflict(id) do nothing;
insert into public.portfolio_work(id,title,category,year,description,sort_order) values
('empire-60','Empire Restaurant · 60th Anniversary','Brand Campaign','2026','Contributed to anniversary campaign coordination for Empire Restaurant, celebrating its legacy from 1966 to 2026. Work included brand marketing, creative planning, influencer coordination, campaign communication, and cinematic brand film coordination. The overall campaign was associated with an approximate ₹2 crore marketing spend; this refers to the campaign scale, not an individual budget.',0),
('influencer','Influencer Marketing Coordination','Campaign Execution','2026','Coordinated influencer marketing activities and campaign touchpoints to support brand visibility, creative consistency, and audience reach.',1),
('cinematic','Cinematic Brand Film Coordination','Creative Production','2026','Supported creative planning and coordination for cinematic brand storytelling, aligning visual content with campaign objectives and brand identity.',2),
('systems','Creative Systems & AI-Assisted Production','Creative Technology','Ongoing','Exploring AI-assisted video creation, reference-based visual consistency, cinematic prompt design, professional PDFs, structured Excel workbooks, and efficient content workflows.',3)
on conflict(id) do nothing;

-- Create public media bucket. Public URLs are readable by everyone, but only authenticated users may upload/delete.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('portfolio-media','portfolio-media',true,104857600,array['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','video/quicktime'])
on conflict (id) do update set public = true, file_size_limit = 104857600;
drop policy if exists "Public can view portfolio media" on storage.objects;
create policy "Public can view portfolio media" on storage.objects for select using (bucket_id = 'portfolio-media');
drop policy if exists "Authenticated can upload portfolio media" on storage.objects;
create policy "Authenticated can upload portfolio media" on storage.objects for insert to authenticated with check (bucket_id = 'portfolio-media');
drop policy if exists "Authenticated can update portfolio media" on storage.objects;
create policy "Authenticated can update portfolio media" on storage.objects for update to authenticated using (bucket_id = 'portfolio-media') with check (bucket_id = 'portfolio-media');
drop policy if exists "Authenticated can delete portfolio media" on storage.objects;
create policy "Authenticated can delete portfolio media" on storage.objects for delete to authenticated using (bucket_id = 'portfolio-media');
