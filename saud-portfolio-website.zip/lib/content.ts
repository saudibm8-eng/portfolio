export type WorkItem = {
  id: string; title: string; category: string; year: string; description: string;
  media_url?: string | null; media_type?: string | null; featured?: boolean;
};
export const fallbackProfile = {
  name: "Saud",
  role: "Brand Marketing · Digital Growth · Creative Production",
  line: "I turn brand objectives into campaigns people remember.",
  about: "I work at the intersection of brand strategy, digital marketing, creative production, and execution. My work spans restaurant marketing, influencer coordination, campaign planning, brand communication, and cinematic content. I enjoy building ideas from scratch, structuring campaigns, and using emerging tools to create better work and more efficient systems.",
  now: "Building sharper brand stories, better digital campaigns, and repeatable creative workflows.",
  email: "",
  instagram: "",
  linkedin: "",
  location: "Bengaluru, India"
};
export const fallbackSkills = [
  { group: "Brand Marketing", skills: ["Brand Strategy", "Campaign Planning", "Brand Positioning", "Brand Communication", "Integrated Marketing"] },
  { group: "Social Media Management", skills: ["Content Calendar Planning", "Reels Strategy", "Instagram Management", "Community Management", "Social Analytics", "Audience Growth"] },
  { group: "Digital Marketing", skills: ["Meta Ads", "Audience Targeting", "Lead Generation", "Campaign Optimization", "Customer Acquisition"] },
  { group: "Influencer & Production", skills: ["Influencer Coordination", "Creative Planning", "Cinematic Brand Film Coordination", "Content Production", "Storytelling"] },
  { group: "AI, Tools & Systems", skills: ["AI Video Creation", "Prompt Engineering", "PDF Creation", "Advanced Excel Workbooks", "Spreadsheet Design", "Workflow Automation"] }
];
export const fallbackWork: WorkItem[] = [
  {
    id: "empire-60",
    title: "Empire Restaurant · 60th Anniversary",
    category: "Brand Campaign",
    year: "2026",
    description: "Contributed to anniversary campaign coordination for Empire Restaurant, celebrating its legacy from 1966 to 2026. Work included brand marketing, creative planning, influencer coordination, campaign communication, and cinematic brand film coordination. The overall campaign was associated with an approximate ₹2 crore marketing spend; this refers to the campaign scale, not an individual budget."
  },
  {
    id: "influencer",
    title: "Influencer Marketing Coordination",
    category: "Campaign Execution",
    year: "2026",
    description: "Coordinated influencer marketing activities and campaign touchpoints to support brand visibility, creative consistency, and audience reach."
  },
  {
    id: "cinematic",
    title: "Cinematic Brand Film Coordination",
    category: "Creative Production",
    year: "2026",
    description: "Supported creative planning and coordination for cinematic brand storytelling, aligning visual content with campaign objectives and brand identity."
  },
  {
    id: "systems",
    title: "Creative Systems & AI-Assisted Production",
    category: "Creative Technology",
    year: "Ongoing",
    description: "Exploring AI-assisted video creation, reference-based visual consistency, cinematic prompt design, professional PDFs, structured Excel workbooks, and efficient content workflows."
  }
];