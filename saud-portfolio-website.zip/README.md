# Saud Portfolio — deployable starter

A responsive portfolio with animated editorial design, project filters, skills, editable profile content, image/video uploads, password updates, and a protected admin dashboard.

## Important deployment note
This project is not online until you deploy it. The dashboard uses Supabase Auth, database tables, and Storage. Do not add a password directly to client code or use a front-end-only password gate.

## 1. Create Supabase backend
1. Create a project at https://supabase.com.
2. Open **SQL Editor** and run `supabase-setup.sql`.
3. In **Authentication → Users**, create your owner user with your email and a strong password.
4. Disable public signups in Authentication settings. Do not share the admin credentials.
5. Copy Project URL and anon/public key from Project Settings → API.

## 2. Configure local environment
Copy `.env.example` to `.env.local` and fill in:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`

These are public client values. Never put a Supabase service-role key in this project or in any `NEXT_PUBLIC_` variable.

## 3. Run
Requires Node.js 20 or newer.

```bash
npm install
npm run dev
```

Open http://localhost:3000. `/admin` is the dashboard route.

## 4. Deploy publicly on Vercel
1. Upload this folder to a private GitHub repository.
2. Import that repository at https://vercel.com.
3. Add the two environment variables from `.env.local` in Vercel Project Settings → Environment Variables.
4. Deploy. Connect a custom domain in Vercel if desired.
5. Test the public homepage, admin login, editing, media upload, and password update after deployment.

## Dashboard features
- Edit hero statement, about text, current focus, contact links, and location.
- Add/edit/remove skill groups.
- Add/edit/remove projects and upload images or videos.
- Change the password for the currently signed-in Supabase administrator.
- Public page reads published profile, skills, and work from Supabase.

## Security notes
- The database uses row-level security (RLS). Public visitors can read portfolio content; authenticated users can write.
- Only create trusted admin accounts in Supabase and disable sign-ups. If multiple authenticated users exist, they would all have write access; for strict single-owner access, replace the broad authenticated policies with an explicit allowlist or role-based policy.
- Uploaded files are publicly readable by design because they appear in the public portfolio. Do not upload private files.
- Password changes require an authenticated session. Use a strong unique password and protect the Supabase account with MFA where available.
- This starter does not include analytics, a contact form backend, or a CV download until you add those.
- The ₹2 crore marketing spend wording is included as user-provided campaign context. Verify authorization and accuracy before publishing it publicly.
- Add your actual email and social profile URLs through `/admin` before sharing the site.
