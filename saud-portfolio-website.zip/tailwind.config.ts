import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./app/**/*.{js,ts,jsx,tsx,mdx}", "./components/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: { extend: { fontFamily: { sans: ["Arial", "Helvetica", "sans-serif"] }, colors: { ink: "#101010", acid: "#d9ff43" } } },
  plugins: []
};
export default config;