 "use client";
import { useEffect, useState, ChangeEvent } from "react";
import { supabaseBrowser } from "@/lib/supabase";
import { fallbackProfile, fallbackSkills, fallbackWork, type WorkItem } from "@/lib/content";
import { ArrowLeft, LogOut, Save, Plus, Trash2, Upload, LockKeyhole, Image as ImageIcon, Video } from "lucide-react";

type Profile = typeof fallbackProfile;
export default function AdminPage() {
  const [ready, setReady] = useState(false);
  const [session, setSession] = useState<any>(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [profile, setProfile] = useState<Profile>(fallbackProfile);
  const [skills, setSkills] = useState<any[]>(fallbackSkills);
  const [work, setWork] = useState<WorkItem[]>(fallbackWork);
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const [tab, setTab] = useState("profile");

  useEffect(() => {
    let active = true;
    try {
      const db = supabaseBrowser();
      db.auth.getSession().then(({ data }) => { if (active) { setSession(data.session); setReady(true); if (data.session) loadData(); } });
      const { data: sub } = db.auth.onAuthStateChange((_event, s) => { setSession(s); if (s) loadData(); });
      return () => { active = false; sub.subscription.unsubscribe(); };
    } catch (e: any) { setNotice(e.message); setReady(true); }
  }, []);

  async function loadData() {
    try {
      const db = supabaseBrowser();
      const [p,s,w] = await Promise.all([
        db.from("portfolio_profile").select("content").eq("id",1).maybeSingle(),
        db.from("portfolio_skills").select("content").eq("id",1).maybeSingle(),
        db.from("portfolio_work").select("*").order("sort_order",{ascending:true})
      ]);
      if (p.data?.content) setProfile({ ...fallbackProfile, ...p.data.content });
      if (s.data?.content) setSkills(s.data.content);
      if (w.data?.length) setWork(w.data as WorkItem[]);
    } catch (e: any) { setNotice(e.message); }
  }
  async function signIn(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setNotice("");
    try { const db=supabaseBrowser(); const { error }=await db.auth.signInWithPassword({email,password}); if(error) throw error; setPassword(""); }
    catch(e:any){setNotice(e.message || "Sign-in failed.");}
    finally{setBusy(false);}
  }
  async function saveAll() {
    setBusy(true); setNotice("");
    try {
      const db=supabaseBrowser();
      const p=await db.from("portfolio_profile").upsert({id:1,content:profile});
      if(p.error) throw p.error;
      const s=await db.from("portfolio_skills").upsert({id:1,content:skills});
      if(s.error) throw s.error;
      const del=await db.from("portfolio_work").delete().neq("id","__none__");
      if(del.error) throw del.error;
      if(work.length){const ins=await db.from("portfolio_work").insert(work.map((w,i)=>({...w,sort_order:i})));if(ins.error)throw ins.error;}
      setNotice("Changes saved. Refresh the public portfolio to see the updates.");
    } catch(e:any){setNotice(e.message || "Could not save. Check your database setup.");}
    finally{setBusy(false);}
  }
  async function uploadMedia(e: ChangeEvent<HTMLInputElement>, workId: string) {
    const file=e.target.files?.[0]; if(!file)return;
    if(file.size > 100*1024*1024){setNotice("Maximum upload size is 100 MB.");return;}
    setBusy(true);setNotice("Uploading media…");
    try {
      const db=supabaseBrowser(); const safe=file.name.replace(/[^a-zA-Z0-9._-]/g,"-");
      const path=`${crypto.randomUUID()}-${safe}`;
      const {error}=await db.storage.from("portfolio-media").upload(path,file,{upsert:false,contentType:file.type});
      if(error)throw error;
      const {data}=db.storage.from("portfolio-media").getPublicUrl(path);
      setWork(prev=>prev.map(w=>w.id===workId?{...w,media_url:data.publicUrl,media_type:file.type}:w));
      setNotice("Media uploaded. Save changes to attach it to this project.");
    }catch(e:any){setNotice(e.message || "Upload failed.");}
    finally{setBusy(false);e.target.value="";}
  }
  async function changePassword(e: React.FormEvent) {
    e.preventDefault();setBusy(true);setNotice("");
    try { const db=supabaseBrowser();const {error}=await db.auth.updateUser({password});if(error)throw error;setPassword("");setNotice("Password updated."); }
    catch(e:any){setNotice(e.message || "Password update failed.");}
    finally{setBusy(false);}
  }
  function updateWork(id:string, patch:Partial<WorkItem>){setWork(prev=>prev.map(w=>w.id===id?{...w,...patch}:w));}
  if(!ready) return <main className="admin-wrap"><p>Loading dashboard…</p></main>;
  if(!session) return <main className="admin-wrap"><a className="back-link" href="/"><ArrowLeft size={16}/> Back to portfolio</a><form className="login-card" onSubmit={signIn}><div className="admin-symbol"><LockKeyhole/></div><span className="section-index">PRIVATE AREA / 01</span><h1>Owner access.</h1><p>Sign in with the administrator account created in Supabase.</p><label>Email<input type="email" autoComplete="username" value={email} onChange={e=>setEmail(e.target.value)} required /></label><label>Password<input type="password" autoComplete="current-password" value={password} onChange={e=>setPassword(e.target.value)} required /></label><button className="button button-dark" disabled={busy}>{busy?"Signing in…":"Unlock dashboard"} <LockKeyhole size={16}/></button>{notice&&<p className="notice">{notice}</p>}<small>No public sign-up is enabled. Create the owner account inside Supabase.</small></form></main>;
  return <main className="admin-wrap"><header className="admin-top"><a className="back-link" href="/"><ArrowLeft size={16}/> View portfolio</a><div><span className="admin-pill"><span className="status-dot"/> AUTHENTICATED</span><button className="logout" onClick={async()=>{await supabaseBrowser().auth.signOut();setSession(null);}}><LogOut size={15}/> Sign out</button></div></header>
    <div className="admin-heading"><span className="section-index">PORTFOLIO CONTROL ROOM</span><h1>Make it yours<span>.</span></h1><p>Edit your public profile, skills, projects, and media from one place.</p></div>
    <div className="admin-tabs">{[["profile","Profile"],["skills","Skills"],["work","Work & media"],["security","Security"]].map(([id,label])=><button key={id} className={tab===id?"selected":""} onClick={()=>setTab(id)}>{label}</button>)}</div>
    {tab==="profile"&&<section className="admin-panel"><h2>Profile details</h2><div className="form-grid">{([["name","Name"],["role","Role / headline"],["line","Hero statement"],["location","Location"],["email","Email"],["instagram","Instagram URL"],["linkedin","LinkedIn URL"],["now","Right now"]] as const).map(([k,label])=><label key={k}>{label}<input value={profile[k]} onChange={e=>setProfile({...profile,[k]:e.target.value})}/></label>)}<label className="full">About<textarea rows={6} value={profile.about} onChange={e=>setProfile({...profile,about:e.target.value})}/></label></div><button className="button button-dark" onClick={saveAll} disabled={busy}><Save size={16}/> Save all changes</button></section>}
    {tab==="skills"&&<section className="admin-panel"><div className="panel-title"><h2>Capabilities</h2><button className="outline-button" onClick={()=>setSkills([...skills,{group:"New skill group",skills:[]}])}><Plus size={15}/> Add group</button></div>{skills.map((g,i)=><div className="skill-edit" key={i}><div className="skill-edit-head"><input value={g.group} onChange={e=>setSkills(skills.map((x,j)=>j===i?{...x,group:e.target.value}:x))}/><button className="icon-button" onClick={()=>setSkills(skills.filter((_,j)=>j!==i))} aria-label="Delete group"><Trash2 size={16}/></button></div><label>Skills, separated by commas<textarea rows={2} value={g.skills.join(", ")} onChange={e=>setSkills(skills.map((x,j)=>j===i?{...x,skills:e.target.value.split(",").map((v:string)=>v.trim()).filter(Boolean)}:x))}/></label></div>)}<button className="button button-dark" onClick={saveAll} disabled={busy}><Save size={16}/> Save skills</button></section>}
    {tab==="work"&&<section className="admin-panel"><div className="panel-title"><h2>Projects & media</h2><button className="outline-button" onClick={()=>setWork([...work,{id:crypto.randomUUID(),title:"New project",category:"Project",year:String(new Date().getFullYear()),description:"Add a project description.",media_url:null,media_type:null}])}><Plus size={15}/> Add project</button></div><p className="panel-help">Upload a photo or video for each project. Supported media depends on your Supabase storage configuration. Keep files under 100 MB.</p>{work.map((w,i)=><div className="work-edit" key={w.id}><div className="work-edit-head"><span>PROJECT {String(i+1).padStart(2,"0")}</span><button className="icon-button" onClick={()=>setWork(work.filter(x=>x.id!==w.id))} aria-label="Delete project"><Trash2 size={16}/></button></div><div className="form-grid"><label>Title<input value={w.title} onChange={e=>updateWork(w.id,{title:e.target.value})}/></label><label>Category<input value={w.category} onChange={e=>updateWork(w.id,{category:e.target.value})}/></label><label>Year<input value={w.year} onChange={e=>updateWork(w.id,{year:e.target.value})}/></label><label className="full">Description<textarea rows={4} value={w.description} onChange={e=>updateWork(w.id,{description:e.target.value})}/></label></div><div className="upload-row"><label className="upload-button"><Upload size={16}/> Upload photo/video<input type="file" accept="image/*,video/*" onChange={e=>uploadMedia(e,w.id)} hidden/></label>{w.media_url&&<><a className="media-url" href={w.media_url} target="_blank" rel="noreferrer">Preview current media</a><button className="outline-button" onClick={()=>updateWork(w.id,{media_url:null,media_type:null})}>Remove media</button></>}</div></div>)}<button className="button button-dark" onClick={saveAll} disabled={busy}><Save size={16}/> Save all projects</button></section>}
    {tab==="security"&&<section className="admin-panel"><h2>Account security</h2><p className="panel-help">Change the password for your authenticated administrator account. Use a unique, strong password.</p><form className="password-form" onSubmit={changePassword}><label>New password<input type="password" minLength={10} autoComplete="new-password" value={password} onChange={e=>setPassword(e.target.value)} required/><small>Use at least 10 characters. A password manager is recommended.</small></label><button className="button button-dark" disabled={busy}><LockKeyhole size={16}/> Update password</button></form></section>}
    {notice&&<div className="admin-notice">{notice}</div>}
    <p className="admin-footnote">Changes are stored in Supabase. The public website reads published portfolio content; dashboard writes require an authenticated account and database policies.</p>
  </main>;
}