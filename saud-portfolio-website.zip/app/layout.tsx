import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "Saud — Brand Marketing & Creative",
  description: "Brand marketing, campaigns, cinematic storytelling, and creative systems by Saud.",
  metadataBase: new URL("https://example.com"),
  openGraph: { title: "Saud — Brand Marketing & Creative", description: "Strategy, stories, and execution.", type: "website" }
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}